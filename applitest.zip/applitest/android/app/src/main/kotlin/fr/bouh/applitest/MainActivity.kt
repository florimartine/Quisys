package fr.bouh.applitest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
