import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'api_service.dart';
import 'models/member.dart';
import 'member_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  TextEditingController _tokenController = TextEditingController();
  List<Member> _members = [];
  String? _selectedRoleOrHobby;
  String? _selectedValue;

  late TabController _tabController;
  List<String> _customRoles = [];
  List<String> _customHobbies = [];

  TextEditingController _roleController = TextEditingController();
  TextEditingController _hobbyController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(_onTabChanged); // Ajouter l'écouteur pour détecter les changements d'onglet
    _loadSavedMembers();
    _loadCustomizations(); // Charger les personnalisations
  }

  // Réinitialiser le questionnaire lors du changement d'onglet
  void _onTabChanged() {
    if (_tabController.index == 1) {
      setState(() {
        _selectedRoleOrHobby = null; // Réinitialiser la sélection du rôle
        _selectedValue = null; // Réinitialiser la sélection du hobby
      });
    }
  }

  // Charger les rôles et hobbies personnalisés depuis SharedPreferences
  Future<void> _loadCustomizations() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _customRoles = prefs.getStringList('custom_roles') ?? [];
      _customHobbies = prefs.getStringList('custom_hobbies') ?? [];
      // Trier les personnalisations par ordre alphabétique
      _customRoles.sort();
      _customHobbies.sort();
    });
  }

  // Sauvegarder les rôles et hobbies personnalisés
  Future<void> _saveCustomizations() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setStringList('custom_roles', _customRoles);
    prefs.setStringList('custom_hobbies', _customHobbies);
  }

  // Ajouter un rôle personnalisé
  void _addCustomRole() {
    if (_roleController.text.isNotEmpty) {
      setState(() {
        _customRoles.add(_roleController.text);
        _customRoles.sort(); // Trier après l'ajout
        _roleController.clear();
      });
      _saveCustomizations();
    }
  }

  // Ajouter un hobby personnalisé
  void _addCustomHobby() {
    if (_hobbyController.text.isNotEmpty) {
      setState(() {
        _customHobbies.add(_hobbyController.text);
        _customHobbies.sort(); // Trier après l'ajout
        _hobbyController.clear();
      });
      _saveCustomizations();
    }
  }

  // Supprimer un rôle personnalisé et l'enlever des membres et du questionnaire
  void _removeCustomRole(String role) {
    if (_selectedRoleOrHobby == role) {
      setState(() {
        _selectedRoleOrHobby = null; // Supprimer le rôle sélectionné dans le questionnaire
      });
    }
    setState(() {
      _customRoles.remove(role);

      // Supprimer ce rôle de tous les membres
      for (var member in _members) {
        member.removeCustomInfo(role); // Supprimer le rôle des membres
      }
    });
    _saveCustomizations();
    _saveMembers();
  }

  // Supprimer un hobby personnalisé et l'enlever des membres et du questionnaire
  void _removeCustomHobby(String hobby) {
    if (_selectedValue == hobby) {
      setState(() {
        _selectedValue = null; // Supprimer le hobby sélectionné dans le questionnaire
      });
    }
    setState(() {
      _customHobbies.remove(hobby);

      // Supprimer ce hobby de tous les membres
      for (var member in _members) {
        member.removeCustomInfo(hobby); // Supprimer le hobby des membres
      }
    });
    _saveCustomizations();
    _saveMembers();
  }

  // Charger les membres sauvegardés depuis SharedPreferences
  Future<void> _loadSavedMembers() async {
    final prefs = await SharedPreferences.getInstance();
    final String? savedMembers = prefs.getString('members');
    if (savedMembers != null) {
      List<dynamic> membersJson = json.decode(savedMembers);
      setState(() {
        _members = membersJson.map((memberData) => Member.fromJson(memberData)).toList();
        _members.sort((a, b) => a.name.compareTo(b.name)); // Trier par ordre alphabétique
      });
    }
  }

  // Sauvegarder les membres dans SharedPreferences
  Future<void> _saveMembers() async {
    final prefs = await SharedPreferences.getInstance();
    List<Map<String, dynamic>> membersJson = _members.map((member) => member.toJson()).toList();
    prefs.setString('members', json.encode(membersJson)); // Sauvegarde en JSON
  }

  // Fonction pour récupérer les membres via l'API et synchroniser avec ceux stockés
  Future<void> _getMembers() async {
    String token = _tokenController.text.trim();
    if (token.isEmpty) {
      setState(() {
        _members = []; // Vider la liste si aucun token n'est fourni
      });
    } else {
      List<Member> membersFromApi = await fetchMembers(token);

      // Charger les membres sauvegardés depuis SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      final String? savedMembers = prefs.getString('members');
      List<Member> savedMembersList = [];

      if (savedMembers != null) {
        List<dynamic> savedMembersJson = json.decode(savedMembers);
        savedMembersList = savedMembersJson
            .map((memberData) => Member.fromJson(memberData))
            .toList();
      }

      // Synchroniser les membres sauvegardés avec ceux de l'API
      List<Member> membersToKeep = [];
      for (var apiMember in membersFromApi) {
        bool found = false;
        for (var savedMember in savedMembersList) {
          if (savedMember.name == apiMember.name) {
            // Fusionner les informations supplémentaires, conserver les données internes
            savedMember.additionalInfo = savedMember.additionalInfo ?? apiMember.additionalInfo;
            membersToKeep.add(savedMember);
            found = true;
            break;
          }
        }
        if (!found) {
          membersToKeep.add(apiMember); // Ajouter le membre de l'API s'il n'est pas trouvé
        }
      }

      // Supprimer les membres sauvegardés qui ne sont plus présents dans l'API
      savedMembersList.retainWhere((savedMember) =>
          membersToKeep.any((member) => member.name == savedMember.name));

      // Mettre à jour la liste des membres avec ceux à garder
      setState(() {
        _members = membersToKeep;
        _members.sort((a, b) => a.name.compareTo(b.name)); // Trier par ordre alphabétique
      });

      // Sauvegarder les membres synchronisés dans SharedPreferences
      _saveMembers();
    }
  }

  // Afficher le questionnaire avec les rôles et hobbies personnalisés
  Widget _buildQuestionnaire() {
    final Map<String, List<String>> infoOptions = {
      'Rôle': [..._customRoles, 'Développeur', 'Designer', 'Manager', 'Testeur']..sort(),
      'Hobbies': [..._customHobbies, 'Lecture', 'Jeux Vidéo', 'Sport', 'Voyages']..sort(),
    };

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Sélection du rôle
          DropdownButton<String>(
            hint: Text('Sélectionner un rôle'),
            value: _selectedRoleOrHobby,
            onChanged: (newValue) {
              setState(() {
                _selectedRoleOrHobby = newValue;
              });
            },
            items: infoOptions['Rôle']!.map((String value) {
              return DropdownMenuItem<String>(value: value, child: Text(value));
            }).toList(),
          ),
          SizedBox(height: 20),
          // Sélection du hobby
          DropdownButton<String>(
            hint: Text('Sélectionner un hobby'),
            value: _selectedValue,
            onChanged: (newValue) {
              setState(() {
                _selectedValue = newValue;
              });
            },
            items: infoOptions['Hobbies']!.map((String value) {
              return DropdownMenuItem<String>(value: value, child: Text(value));
            }).toList(),
          ),
          SizedBox(height: 20),

          // Bouton pour réinitialiser les sélections
          ElevatedButton(
            onPressed: () {
              setState(() {
                _selectedRoleOrHobby = null; // Réinitialiser le rôle
                _selectedValue = null; // Réinitialiser le hobby
              });
            },
            child: Text('Réinitialiser les sélections'),
          ),

          SizedBox(height: 20),
          // Afficher les membres correspondant aux critères
          if (_selectedRoleOrHobby != null || _selectedValue != null) ...[
            Text('Membres correspondant aux critères :'),
            SizedBox(height: 10),
            Expanded(
              child: ListView(
                children: _members
                    .where((member) {
                  final matchesRole = _selectedRoleOrHobby == null ||
                      member.additionalInfo.contains('Rôle: $_selectedRoleOrHobby');
                  final matchesHobby = _selectedValue == null ||
                      member.additionalInfo.contains('Hobbies: $_selectedValue');
                  return matchesRole && matchesHobby;
                })
                    .map((member) {
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8),
                    child: ListTile(
                      leading: member.avatarUrl.isNotEmpty
                          ? CircleAvatar(backgroundImage: NetworkImage(member.avatarUrl))
                          : Icon(Icons.person),
                      title: Text(member.name),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MemberDetailScreen(
                              member: member,
                              onSave: _saveMembers,
                            ),
                          ),
                        );
                      },
                    ),
                  );
                })
                    .toList(),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // Afficher la liste des membres avec un bouton de suppression pour chaque membre
  Widget _buildMemberList() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          TextField(
            controller: _tokenController,
            decoration: InputDecoration(
              labelText: 'Entrez votre token Discord',
              border: OutlineInputBorder(),
            ),
            obscureText: true,
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: _getMembers,
            child: Text('Obtenir les membres'),
          ),
          SizedBox(height: 16),
          // Afficher la liste des membres récupérés
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: _members.map((member) {
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8),
                    child: ListTile(
                      leading: member.avatarUrl.isNotEmpty
                          ? CircleAvatar(backgroundImage: NetworkImage(member.avatarUrl))
                          : Icon(Icons.person),
                      title: Text(member.name),
                      trailing: IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () {
                          setState(() {
                            _members.remove(member);
                          });
                          _saveMembers();
                        },
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MemberDetailScreen(
                              member: member,
                              onSave: _saveMembers,
                            ),
                          ),
                        );
                      },
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('PluralKit API Demo'),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Membres'),
            Tab(text: 'Questionnaire'),
            Tab(text: 'Réponse personnalisée'),
          ],
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.grey,
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildMemberList(),
          _buildQuestionnaire(),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Formulaire pour ajouter un rôle personnalisé
                TextField(
                  controller: _roleController,
                  decoration: InputDecoration(
                    labelText: 'Ajouter un rôle personnalisé',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: _addCustomRole,
                  child: Text('Ajouter un rôle'),
                ),
                SizedBox(height: 20),
                // Formulaire pour ajouter un hobby personnalisé
                TextField(
                  controller: _hobbyController,
                  decoration: InputDecoration(
                    labelText: 'Ajouter un hobby personnalisé',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: _addCustomHobby,
                  child: Text('Ajouter un hobby'),
                ),
                SizedBox(height: 20),
                // Liste des rôles personnalisés
                Text('Rôles personnalisés :'),
                Expanded(
                  child: ListView(
                    children: _customRoles.map((role) {
                      return ListTile(
                        title: Text(role),
                        trailing: IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () => _removeCustomRole(role),
                        ),
                      );
                    }).toList(),
                  ),
                ),
                SizedBox(height: 20),
                // Liste des hobbies personnalisés
                Text('Hobbies personnalisés :'),
                Expanded(
                  child: ListView(
                    children: _customHobbies.map((hobby) {
                      return ListTile(
                        title: Text(hobby),
                        trailing: IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () => _removeCustomHobby(hobby),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
